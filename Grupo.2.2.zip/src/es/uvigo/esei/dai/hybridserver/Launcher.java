package es.uvigo.esei.dai.hybridserver;



////// 	AUTORES	/////

/************************************/
/*	JOSE JUAN DIOS OTERO			*/	
/*			Y						*/
/*	MAIECO RODRIGUES DIEZ			*/
/*									*/
/************************************/


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Launcher {
	
	public static void main(String[] args) {
		//Cargamos las propiedades del archivo config.conf
		Properties properties= loadPropertiesFromFile();
			
			//Si no hay problemas en la lectura del archivo, en caso contrario se cargaran la por defecto del HybridServer
		    if(properties!=null){
		    	HybridServer server = new HybridServer(properties);
		    	server.start();
		    }else{	
		    	
			//Instanciamos con las propiedades por defecto
			HybridServer server = new HybridServer();
			//El servidor tiene que ser un hilo para luego poder pararlo.
			server.start();
		}
		
		

	}

	private static Properties loadPropertiesFromFile() {
		Properties properts= new Properties();
		try(BufferedReader bfr = new BufferedReader(
									new FileReader("config.conf"))){
			String line="";
			while(!(line=bfr.readLine()).equals("")){
				if(line.contains("=")){
					String[] parts = line.split("=");
					properts.put(parts[0], parts[1]);
					}
			}
			
			return properts;
			
		} catch (IOException e) {
			return null;
		}
		
	}

}
