package es.uvigo.esei.dai.hybridserver.http;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;


public class IMDAO implements Dao {
	private Map<String,HTML> pages;
	
	public IMDAO(Map<String, String> initialPages){
		pages= new HashMap<String, HTML>();
		for(String key : initialPages.keySet()){
			insertResource(key, initialPages.get(key));
		}
				
	}
	
	public IMDAO(){
		pages= new HashMap<String, HTML>();
		String body="";
              
        for(int i=0; i<5 ; i++){        
    		body+="<html>\n";
            body+="<body>\n";
            body+="<h1>Welcome to, Hybrid Server!" + "Pagina " + String.valueOf(i) + "</h1>\n";
            body+="</body>\n";
            body+="</html>\n";
        	UUID uuid= java.util.UUID.randomUUID();
        	System.out.println(uuid.toString());
        	insertResource(uuid.toString(), body);
        	body="";
        }     
		
	}
	
	@Override
	public void setConnection(Connection connection) {
		// nothing to do
		
	}
	

	@Override
	public HTML insertResource(String uuid, String content) {
		this.pages.put(uuid, new HTML(uuid,content));
		return this.pages.get(uuid);
	}

	@Override
	public HTML insertResource(String content) {
		UUID uuid = java.util.UUID.randomUUID();
		HTML html = new HTML(uuid.toString(), content);
		this.pages.put(uuid.toString(), html);
		
		///Devuelvo un nuevo objeto porque al cambiar el content para la respuesta
		// no puedo referenciar el insertado. Esto no pasa con DBDAO
		return new HTML(uuid.toString(),content);
	}

	@Override
	public void deleteResource(String uuid) {
		this.pages.remove(uuid);
		
	}

	@Override
	public void updateResource(HTML html) {
		this.pages.put(html.getUUID(), html);
		
	}

	@Override
	public HTML getResource(String uuid) {
		return this.pages.get(uuid);
	}

	@Override
	public List<HTML> getAllResources() {
		List<HTML> list= new ArrayList<HTML>();
		for(String uuid : this.pages.keySet()){
			list.add(this.pages.get(uuid));
		}
		return list;
	}

	@Override
	public void closeConnection() throws SQLException {
		//  Nothing to do	
	}

	



	
	

}
