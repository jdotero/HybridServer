package es.uvigo.esei.dai.hybridserver.http;

public class HTML {
	
	public HTML(String id, String cont){
		this.uuid=id;
		this.content=cont;
		this.length=cont.length();
	}
	
	
	public void setUUID(String id){
		this.uuid=id;
	}
	
	
	public void setContent(String content){
		this.content=content;
		this.length=content.length();
	}
	
		
	public String getUUID(){
		return this.uuid;
	}
	
	
	public String getContent(){
		return this.content;
	}
	
	public String getType(){
		return this.type;
	}
	
	public int getLength(){
		return this.length;
	}

	
	private  String uuid;
	private  String content;
	private  String type="text/HTML";
	private  int length;
}
