package es.uvigo.esei.dai.hybridserver.http;


import java.sql.SQLException;
import java.util.Map;

import es.uvigo.esei.dai.hybridserver.HybridServer;
import es.uvigo.esei.dai.hybridserver.http.HTTPHeaders;
import es.uvigo.esei.dai.hybridserver.http.HTTPRequest;
import es.uvigo.esei.dai.hybridserver.http.HTTPResponse;
import es.uvigo.esei.dai.hybridserver.http.HTTPResponseStatus;

public class Router {
	public HTTPResponse process(HTTPRequest httpRequest, Dao d){
		this.dao=d;
		this.response= new HTTPResponse();
		this.request= httpRequest;
		try{
			//En caso de que el httpRequest venga null el parser a fallado asi que soltamos S400
			if(httpRequest==null){
				setResponseStatusLine(HTTPHeaders.HTTP_1_1, HTTPResponseStatus.S400);
				setResponseParameters();
				this.dao.closeConnection();
				return this.response;
			}else{
						 	
						switch(this.request.getMethod()){
						case GET: buildResponseGET();
								  break;
								 
											
						case POST: buildResponsePOST();
								   break;
								
						case DELETE:buildResponseDELETE();
									break;
									 
						
						default: setStatusLineToInternalError();
								 break;
						
						}
						dao.closeConnection();
						return this.response;
						
					}//else	
		//En caso de SQLException soltamos un error S500 con setStatusLineToInternalError y parametros por defecto.
		}catch(SQLException e){
			e.printStackTrace();
			setStatusLineToInternalError();
			setResponseParameters();
			return this.response;
		}
	}
	


	private void buildResponseGET() throws SQLException{
		Map<String, String> resourceParameters= request.getResourceParameters();
			//Si el recurso solicitado es de tipo html
			if(this.request.getResourceName().equals("")){
				
				this.html=new HTML("welcome", getWelcomeContent());
				setResponseStatusLine(HTTPHeaders.HTTP_1_1, HTTPResponseStatus.S200);
				setResponseParameters();
				setResponseContent(this.html.getContent());

			}else if(this.request.getResourceName().equalsIgnoreCase("html")){	
				//Si contiene el uuid devolvemos la solicitada
				if(resourceParameters.containsKey("uuid")){
					String uuid=resourceParameters.get("uuid");
					
					try{
						this.html=dao.getResource(uuid);
						setResponseStatusLine(HTTPHeaders.HTTP_1_1, HTTPResponseStatus.S200);
						setResponseParameters();
						if(this.html!=null){
						setResponseContent(this.html.getContent());
						}else{
						setResponseStatusLine(HTTPHeaders.HTTP_1_1, HTTPResponseStatus.S404);
						}
						
					}catch(SQLException | IllegalArgumentException e){
						setResponseStatusLine(HTTPHeaders.HTTP_1_1,	HTTPResponseStatus.S404);
						setResponseParameters();
						
					}
					
					
				}else{
					this.html=new HTML("default", createDefaultListContent());
					setResponseStatusLine(HTTPHeaders.HTTP_1_1, HTTPResponseStatus.S200);
					setResponseParameters();
					setResponseContent(this.html.getContent());
					
					}
			
			}else{
				this.html=null;
				setResponseStatusLine(HTTPHeaders.HTTP_1_1, HTTPResponseStatus.S400);
				setResponseParameters();
				
			}
	}

	private void buildResponsePOST() throws SQLException {
			
		Map<String, String> parameters =request.getResourceParameters();
		if(parameters.containsKey("html")){
			this.html=dao.insertResource(parameters.get("html"));
			createPostContent();
			setResponseStatusLine(HTTPHeaders.HTTP_1_1, HTTPResponseStatus.S200);
			setResponseParameters();
			
			
		}else{
			this.html=null;
			setResponseStatusLine(HTTPHeaders.HTTP_1_1, HTTPResponseStatus.S400);
			setResponseParameters();
			
		}
		
	}
	
	private void buildResponseDELETE() throws SQLException {
		
		String uuid="";
		Map<String,String> parameters = this.request.getResourceParameters();
		  if(this.request.getResourceName().equalsIgnoreCase("html")){
			  if((uuid=parameters.get("uuid"))!=null){
				  if((this.html=this.dao.getResource(uuid))!=null){
										  
					  this.dao.deleteResource(uuid);
					  setHtmlContentToDeleted(this.html);
					  setResponseStatusLine(HTTPHeaders.HTTP_1_1, HTTPResponseStatus.S200);
					  setResponseParameters();
					 
				  }else{
					  setResponseStatusLine(HTTPHeaders.HTTP_1_1, HTTPResponseStatus.S404);
					  setResponseParameters();
					  
				  }
				  
				  
			  }else{
				  setResponseStatusLine(HTTPHeaders.HTTP_1_1, HTTPResponseStatus.S404);
				  setResponseParameters();
				 
			  }
			  
		  }else{
			  setResponseStatusLine(HTTPHeaders.HTTP_1_1, HTTPResponseStatus.S404);
			  setResponseParameters();
			  
		  }
	}	
	
///listado con todas las paginas que tenemos.
	private String createDefaultListContent() throws SQLException {
		String content="";
		content+="<html>\n";
		content+="<body>\n";
		content+="<h1>Welcome to Hybrid Server</h1>\n";
		content+="<ul>\n";
			for(HTML ht : this.dao.getAllResources()){
				content+="<li>";
				content+="<a href=http://localhost:"+ 
					HybridServer.getPort()+
					"/html?uuid="+ht.getUUID()+
					">"+ht.getUUID()+
					"</a>";
				content+="</li>\n";
			}
		content+="</ul>\n";
		content+="</body>\n";
		content+="</html>\n";
		return content;
	}
	
	

	private void createPostContent() {
		String body="<html>\n";
	   	body+="<body>\n";
	 	body+="<a href=\"html?uuid="+this.html.getUUID()+
				"\">"+this.html.getUUID()+
				"</a>\n";
	 	body+="</body>\n";
	 	body+="</html>\n";
	 	this.html.setContent(body);
	 	this.response.setContent(body);
	}


		/// 	SETTERS   //// 

	private void setStatusLineToInternalError() {
		setResponseStatusLine(HTTPHeaders.HTTP_1_1, HTTPResponseStatus.S500);
		
	}


	private void setHtmlContentToDeleted(HTML ht) {
		String body="<html>\n";
	   	body+="<body>\n";
	 	body+="<h1>";
	   	body+= ht.getUUID();
	   	body+="  DELETED CORRECTLY";
	   	body+="</h1>\n";
	 	body+="</body>\n";
	 	body+="</html>\n";
	 	ht.setContent(body);
	 	this.response.setContent(body);
		
	}


	private void setResponseContent(String content) {
		this.response.setContent(content);
		
	}


	private void setResponseParameters() {
		this.response.putParameter("Server", "Hybrid Server");
		this.response.putParameter("Connection", "closed");
			//En caso de que el uuid no exista el html esta a null
			if(html!=null){
				this.response.putParameter("Content-Type", html.getType());
		  		this.response.putParameter("Content-Length", String.valueOf(html.getLength()));
			}
	}


	private void setResponseStatusLine(HTTPHeaders header, HTTPResponseStatus status) {
		this.response.setVersion(header.getHeader());
  		this.response.setStatus(status);
  		
	}
	
		/// Welcome Content ///

	private String getWelcomeContent() {
		String content="";
		content+="<html>\n";
		content+="<body>\n";
		content+="<h1>Welcome to Hybrid Server</h1>\n";
		content+="<p>Created by:<p>\n";
		content+="<ul>\n<li>Jose Juan Dios Otero</li>\n";
		content+="<li>Maieco Rodrigues Diez</li>\n</ul>\n";
		content+="</body>\n";
		content+="</html>\n";
		return content;
	}


	private HTTPResponse response;
	private HTTPRequest request;
	private HTML html=null;
	private Dao dao;

}
