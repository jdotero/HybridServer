package es.uvigo.esei.dai.hybridserver.http;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;


//Esto deberia ser un Dao<T> pero para ello deberia instanciarse cuando
// ya se sabe el tipo de dato a utilizar.
// De momento el dao se instancia en el HybridServer por lo que no sabemos
// que tipo de dao necesitaremos.
public interface Dao {
	public void setConnection(Connection connection);
	public HTML insertResource(String content) throws SQLException;
	public HTML insertResource(String uuid, String content) throws SQLException;
	public void deleteResource(String uuid) throws SQLException;
	public void updateResource(HTML html) throws SQLException;
	public HTML  getResource(String uuid) throws SQLException;
	public List<HTML> getAllResources() throws SQLException;
	public void closeConnection()throws SQLException;
	

}
