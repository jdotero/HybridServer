package es.uvigo.esei.dai.hybridserver.http;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import es.uvigo.esei.dai.hybridserver.http.HTTPParseException;
import es.uvigo.esei.dai.hybridserver.http.HTTPRequest;
import es.uvigo.esei.dai.hybridserver.http.HTTPResponse;

public class ServiceThread implements Runnable {
	private final Socket socket;
	private final Properties properties;
    private final Dao dao;
	
	public ServiceThread(Socket s, Properties p, Dao d) {
		this.socket=s;
		this.properties=p;
		this.dao=d;
		
			//Si el dao es de tipo DBDAO necesito una conexion sino no
			if(dao.getClass().equals(DBDAO.class)){
				this.dao.setConnection(doConnection());
			}
	}

	

	@Override
	public void run() {
		//Esta asignacion la hago para que el try con recursos me cierre el socket al final	
		try(Socket socket = this.socket){
			HTTPRequest request = new HTTPRequest(
										new InputStreamReader(
												socket.getInputStream()));
			
			
			Router router = new Router();
			HTTPResponse response = router.process(request,dao);
			
			
			response.print(new  OutputStreamWriter(socket.getOutputStream()));
			
		//En caso se genere un HTTPParseException o IOException se genere un error 400
		}catch(HTTPParseException | IOException e){
					
					Router errorRouter = new Router();
					//Recibe null el HTTPRequest y genera un response S400
					HTTPResponse errorResponse= errorRouter.process(null, this.dao);
					try {
						errorResponse.print(new OutputStreamWriter(socket.getOutputStream()));
					} catch (IOException ioe) {
						ioe.printStackTrace();
					}
					
					
		}
		
		
		
		
	}
	
	private Connection doConnection() {
		
		Connection connection;
		try {
			
			connection = DriverManager.getConnection(properties.getProperty("db.url"),
												 	properties.getProperty("db.user"),
												 	properties.getProperty("db.password"));
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
			return connection;
		
		}
	
	
}
