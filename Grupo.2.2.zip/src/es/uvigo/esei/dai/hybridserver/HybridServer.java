package es.uvigo.esei.dai.hybridserver;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import es.uvigo.esei.dai.hybridserver.http.DBDAO;
import es.uvigo.esei.dai.hybridserver.http.Dao;
import es.uvigo.esei.dai.hybridserver.http.IMDAO;
import es.uvigo.esei.dai.hybridserver.http.ServiceThread;


public class HybridServer {
	
	///	properties ///
	
	///Propiedades final porque no cambian en toda la ejecucion del server
	///Hay que apagar y encender con nuevas propiedades para cambiar.
	private final Properties DBPROPERTIES;
	private static int service_port;
	private static int num_clients;
	
	//Interfaz dao con vistas a la entrega dos.
	private final Dao dao;
	
	
	
	private Thread serverThread;
	private boolean stop;
	
	public HybridServer() {
		//Constructor por defecto y con base de datos en memoria.
		DBPROPERTIES=new Properties(setDeaultProperties());
		dao= new IMDAO();
		
	}
		//Constructor con parametros de inicializacion y con base de datos en memoria, se podria usar tambien con DB
		//no lo hago por las pruebas
	public HybridServer(Map<String,String> pages){
		DBPROPERTIES= new Properties(setDeaultProperties());
		dao= new IMDAO(pages);
	}
	
		//Constructor con propiedades para la inicializacion del servidor.
	public HybridServer(Properties properts){
		this.DBPROPERTIES=properts;
		service_port=Integer.valueOf(this.DBPROPERTIES.getProperty("port"));
		num_clients=Integer.valueOf(this.DBPROPERTIES.getProperty("numClients"));
	
		dao= new DBDAO();
	
	}
	
	private Properties setDeaultProperties() {
		Properties dbp=new Properties();
		
		//Seteamos a valores por defecto puerto y numero de clientes
		service_port=8888;
		num_clients=50;
		dbp.put("db.url", "jdbc:mysql://localhost/hybridserverdb");
		dbp.put("db.user","dai");
		dbp.put("db.pass","daipassword");
		return dbp;
	}
	
	
	//Metodos publicos
	public void start(){
		
		this.serverThread = new Thread(){
			@Override
			public void run(){
				try(final ServerSocket ss= new ServerSocket(service_port)){
					
					ExecutorService poolService= Executors.newFixedThreadPool(num_clients);
					while(true){
						
							Socket clientSocket = ss.accept();
								
								if(stop) break;
								poolService.execute(new ServiceThread(clientSocket,DBPROPERTIES,dao));
								
							}
					
				}catch(IOException e){
					e.printStackTrace();
				}
			}
	
		
	};
	
	this.stop= false;
	this.serverThread.start();
	
	}//run
	
	
	public void stop(){
		
		this.stop = true;
				
				try (Socket socket = new Socket("localhost", service_port)) {
					// Esta conexión se hace, simplemente, para "despertar" el hilo servidor
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
				
				try {
					this.serverThread.join();
				} catch (InterruptedException e) {
					throw new RuntimeException(e);
				}
				
	}
	
	
	
//Metodo para la generacion de enlaces con el puerto del servidor desde router.	
	public static int getPort(){
		return service_port;
	}

}
