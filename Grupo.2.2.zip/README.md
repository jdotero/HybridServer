HybridServer
=================
Proyecto base para la realización de la práctica de la asignatura Desarrollo de Aplicaciones para Internet de la Escuela Superior de Ingeniría Informática de la Universidad de Vigo durante el curso 2014/2015.

GRUPO: 2.2
AUTORES:
	JOSE JUAN DIOS OTERO 35471292W
	MAIECO RODRIGUES DIEZ 77123456B